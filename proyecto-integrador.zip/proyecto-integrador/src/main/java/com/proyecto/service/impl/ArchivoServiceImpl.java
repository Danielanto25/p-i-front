package com.proyecto.service.impl;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import com.proyecto.service.IArchivoService;

@Service
public class ArchivoServiceImpl implements IArchivoService {

	@Value("${ruta-img}")
	private String rutaImagen;

	@Override
	public String guardarImagenPrueba(MultipartFile imagen) throws IOException {
		System.out.println(imagen.getName());
		String extencion2 = FilenameUtils.getExtension(imagen.getOriginalFilename());
		int numero = (int) (Math.random() * 200 + 1);
		File picture = new File(rutaImagen + "/" + imagen.getName() + "" + numero + "." + extencion2);
		imagen.transferTo(picture);

		return "Se Subio el Archivo Correctamente";
	}

}
