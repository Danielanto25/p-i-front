package com.proyecto.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.proyecto.dto.RespuestaDto;
import com.proyecto.service.IArchivoService;

@RestController
@RequestMapping(path = "/archivo")
@CrossOrigin(origins = "*")
public class ArchivoController {

	@Autowired
	private IArchivoService service;

	@PostMapping
	public ResponseEntity<RespuestaDto> guardarArchivo(@RequestPart MultipartFile imagen) throws Exception {

		return new ResponseEntity<RespuestaDto>(new RespuestaDto(service.guardarImagenPrueba(imagen)), HttpStatus.OK);

	}

}
