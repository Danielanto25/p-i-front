import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SubirArchivoComponent } from './pages/subir-archivo/subir-archivo.component';

const routes: Routes = [{
  path:'',component:SubirArchivoComponent
}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
